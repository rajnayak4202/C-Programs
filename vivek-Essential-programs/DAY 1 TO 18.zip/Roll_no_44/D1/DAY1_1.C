#include<stdio.h>
#include<conio.h>
void main()
{
   int a;
   int b;
   int ans;
   clrscr();
   printf("Enter first no:",a);
   scanf("%d",&a);
   printf("Enter second no:",b);
   scanf("%d",&b);
   ans=a+b;
   printf("Addition of two number is:%d",ans);
   getch();
}