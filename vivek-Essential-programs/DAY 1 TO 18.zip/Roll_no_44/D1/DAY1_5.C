//Program to see the use of printf function.
#include<stdio.h>
#include<conio.h>
void main()
{
   clrscr();
   printf("HELLO FRIENDS");
   getch();
}