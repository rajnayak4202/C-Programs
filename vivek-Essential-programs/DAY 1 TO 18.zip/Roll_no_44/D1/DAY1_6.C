#include<stdio.h>
#include<conio.h>
void main()
{
   clrscr();
   printf("Student detail");
   printf("\n\nName:Ravindra");
   printf("\nAddress:Swaminarayan park-8");
   printf("\nMobile no is:7486823895");
   printf("\nEmail id is:ravindraunuri@gmail.com");
   getch();
}