// add of two matrix
#include<stdio.h>
#include<conio.h>

void main()
{
	int matrix1[3][3]={0,1,2,3,4,5,6,7,8};
	int matrix2[3][3];
	int i,j,k,l;
	clrscr();

	printf("  matrix 1 : \n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
		       printf("  %d",matrix1[i][j]);
		}
		printf("\n");

	}
	printf("\n");
	printf("inverse of martix1 : \n");
	printf("  matrix 1 : \n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
		       printf("  %d",matrix1[i][j]);
		}
		printf("\n");

	}
	printf("\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
		       printf("  %d",matrix1[j][i]);
		}
		printf("\n");

	}
	getch();
}

