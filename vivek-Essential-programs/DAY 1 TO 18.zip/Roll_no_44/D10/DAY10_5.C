//String reverse program.
#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
   char str1[10];
   char n[10]="";
   clrscr();
   printf("Enter the string:");
   gets(str1);
   strrev(str1);
   printf("Reverse of the string is:%s",str1);
   getch();
}