//string concatination program.
#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
  char str1[20];
  char str2[20];
  clrscr();
  printf("Enter the first string:");
  gets(str1);
  printf("Enter the second string:");
  gets(str2);
  strcat(str1,str2);
  printf("%s",str1);
  getch();
}