//palindrome
#include<stdio.h>
#include<conio.h>
#include<string.h>

void main()
{
	char str1[10];
	//char str2[10];
	int value;
	clrscr();
	puts("enter the first string : ");
	gets(str1);


	value=strrev(str1);
	if(value==str1)
	{
		puts("is palindrome");
	}
	else
	{
		puts("is not a palindrome");
	}
	getch();
}