//string comperison program.
#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
  char str1[20];
  char str2[20];
  int n;
  clrscr();
  printf("Enter the first string:");
  gets(str1);
  printf("Enter the second string:");
  gets(str2);
  n=strcmp(str1,str2);
  printf("%d",n);
  getch();
}