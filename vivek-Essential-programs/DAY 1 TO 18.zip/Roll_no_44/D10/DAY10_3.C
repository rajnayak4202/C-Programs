//Finding string length program.
#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
  char str1[20];
  int n=0;
  clrscr();
  printf("Enter the first string:");
  gets(str1);
  n=strlen(str1);
  printf("\n\nLenth of the string is:%d",n);
  getch();
}