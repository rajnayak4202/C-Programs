#include<stdio.h>
#include<conio.h>
void main()
{
   int i,ans=1;
   clrscr();
   for(i=1;i<=5;i++)
   {
     ans=ans*i;
   }
   printf("Factorial answer is:%d",ans);
   getch();
}
