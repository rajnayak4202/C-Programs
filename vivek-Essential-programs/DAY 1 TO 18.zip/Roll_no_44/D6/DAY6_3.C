#include<stdio.h>
#include<conio.h>
void main()
{
 int no,i,ans=0;
 clrscr();
 printf("Enter the no.:");
 scanf("%d",&no);
 for(i=0;i<=no;i++)
 {
   ans=ans+i;
 }
 printf("Your answer is:%d",ans);
 getch();
}
