#include<stdio.h>
#include<conio.h>
void main()
{
   int a,b;
   char opr;
   float ans;
   clrscr();
   printf("Enter first no.:");
   scanf("%d",&a);
   printf("Enter second no.:");
   scanf("%d",&b);
   flushall();
   printf("Enter the oprator (+,-,*,/):");
   scanf("%c",&opr);
   switch(opr)
   {
    case '+':
      ans=a+b;
      printf("Addition of two number is:%f",ans);
    break;
    case '-':
      ans=a-b;
      printf("Subtraction of two number is:%f",ans);
    break;
    case '*':
      ans=a*b;
      printf("Multiplication of two number is:%f",ans);
    break;
    case '/':
      ans=a/b;
      printf("Devesion of two number is:%f",ans);
    break;
   }
  getch();
}