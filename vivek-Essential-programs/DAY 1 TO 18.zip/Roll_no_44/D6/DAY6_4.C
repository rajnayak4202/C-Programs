#include<stdio.h>
#include<conio.h>
void main()
{
  int no,ans=0,remainder;
  clrscr();
  printf("Enter 4 digit no.:");
  scanf("%d",&no);
  while(no != 0)
  {
     remainder=no%10;
     ans=ans*10+remainder;
     no /= 10;
  }
  printf("Reverse no is:%d",ans);
  getch();
}