#include<stdio.h>
#include<conio.h>
void main()
{
   int sub1[10]={10,20,30,40,50,60,70,80,90,55};
   int sub2[10]={10,20,30,40,50,60,70,80,90,55};
   int total[10]={0};
   int i,j;
   clrscr();
   printf("Student no. \t Total no. out of(200)");
   printf("\n");
    for(i=0;i<=10;i++)
     {
	    total[i]=sub1[i]+sub2[i];
	    printf("\n   %d \t\t\t %d",i,total[i]);

     }
   getch();
}

