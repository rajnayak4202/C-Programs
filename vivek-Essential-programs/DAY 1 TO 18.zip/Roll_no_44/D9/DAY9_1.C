#include<stdio.h>
#include<conio.h>
void main()
{
   int mark[10]={10,20,30,40,50,60,70,80,90,100};
   int i;
   int max;
   clrscr();
    for(i=0;i<=9;i++)
     {
       printf("\nmark is:%d",mark[i]);
       max=mark[i];
     }
    printf("\nHighest mark is %d",max);
   getch();
}
