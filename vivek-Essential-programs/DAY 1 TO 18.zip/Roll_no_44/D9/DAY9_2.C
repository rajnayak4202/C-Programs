#include<stdio.h>
#include<conio.h>
void main()
{
   int mark[10]={10,20,30,40,50,60,70,80,90,100};
   int i,sum=0;
   int start=3;
   int end=7;
   clrscr();
    for(i=start;i<=end;i++)
     {
       sum=sum+mark[i];
     }
    printf("sum %d",sum);
   getch();
}

