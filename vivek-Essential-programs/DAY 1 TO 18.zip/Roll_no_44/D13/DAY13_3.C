#include<stdio.h>
#include<conio.h>
void main()
{
   int n1=20;
   int n2=30;
   int *p1;
   int *p2;
   clrscr();
   printf("\n%d",n1);
   printf("\n%u",&n1);
   printf("\n%d",n2);
   printf("\n%u",&n2);
   getch();
}