//write a program to create variables using int, float, double, char,
//long and short.
#include<stdio.h>
#include<conio.h>
void main()
{
   int a=10;
   float b=1012.12f;
   char c='R';
   long d=32;
   short e=333;
   double f=234567890;
   clrscr();
   printf("Integer value is:%d",a);
   printf("\nFloat value is:%f",b);
   printf("\nCharacter value is:%c",c);
   printf("\nLong value is:%d",d);
   printf("\nShort value is:%d",e);
   printf("\nDouble value is:%d",&f);
   getch();
}