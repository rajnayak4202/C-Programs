//write a program to find area of triangle.
#include<stdio.h>
#include<conio.h>
void main()
{
   int l;
   int b;
   float area;
   clrscr();
   printf("Enter leangth:",l);
   scanf("%d",&l);
   printf("Enter breadth:",b);
   scanf("%d",&b);
   area=(l*b)/2;
   printf("Area of triangle is:%f",area);
   getch();
}