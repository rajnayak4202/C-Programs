#include<stdio.h>
#include<conio.h>
void main()
{
   char c;
   clrscr();
   printf("\t\t\t-:Pleas enter only character value:-");
   printf("\n\nEnter any character to know it's ASCII value:");
   scanf("%c",&c);
   printf("ASSCI value is:%d",c);
   getch();
}