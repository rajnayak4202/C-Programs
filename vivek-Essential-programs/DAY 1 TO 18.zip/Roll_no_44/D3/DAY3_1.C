//write a program to calculate gross salary.
#include<stdio.h>
#include<conio.h>
void main()
{
  int Basic;
  float DA;
  float HRA;
  float Conveyance;
  float Medical;
  float Other;
  float Gross_pay;
  clrscr();
  printf("Enter basic salary:");
  scanf("%d",&Basic);
  DA=Basic*0.1f;
  printf("\nTotal DA is:%f",DA);
  HRA=Basic*0.08f;
  printf("\nTotal DA is:%f",HRA);
  Conveyance=Basic*0.05f;
  printf("\nTotal DA is:%f",Conveyance);
  Medical=Basic*0.1f;
  printf("\nTotal DA is:%f",Medical);
  Other=Basic*0.05f;
  printf("\nTotal DA is:%f",Other);
  Gross_pay=Basic+DA+HRA+Conveyance+Medical+Other;
  printf("\nTotal gross pay is:%f",Gross_pay);
  getch();
}