#include<stdio.h>
#include<conio.h>
void main()
{
   int a,b,c;
   clrscr();
     printf("Enter the first age:");
     scanf("%d",&a);
     printf("Enter the second age:");
     scanf("%d",&b);
     printf("Enter the third age:");
     scanf("%d",&c);
   if(a>c || b>c)
     {
       if(a>b)
	 {
	    printf("First age is the biggest age then other two");
	 }
       else if(b>a || b>c)
	       {
		  printf("Second age is the bigest age then other two");
	       }
     }
   else
     {
	   printf("Third age is the biggest age then other two");
     }
  getch();
}