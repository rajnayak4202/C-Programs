#include<stdio.h>
#include<conio.h>
void main()
{
  int marks;
  clrscr();
  printf("Enter your marks:");
  scanf("%d",&marks);
    if(marks>=80)
      {
	printf("You got distinction");
      }
    else if(marks>=60)
      {
	printf("You got first class");
      }
    else if(marks>=35)
      {
	printf("You got second class");
      }
    else
      {
       printf("You got fail");
      }
  getch();
}