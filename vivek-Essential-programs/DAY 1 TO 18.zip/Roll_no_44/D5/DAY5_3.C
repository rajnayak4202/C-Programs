#include<stdio.h>
#include<conio.h>
void main()
{
 char ch;
 clrscr();
 printf("Enter any alphabet:");
 scanf("%c",&ch);
   if(ch>=65 && ch<=90 || ch>=97 && ch<=122)
     {
	printf("ASCII value of the entered alphabet is:%d",ch);
     }
   else
     {
	printf("This is not an alphabet");
     }
 getch();
}