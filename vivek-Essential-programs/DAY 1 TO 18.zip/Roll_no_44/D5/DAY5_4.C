#include<stdio.h>
#include<conio.h>
void main()
{
	int p1,p2,p3;
	clrscr();
	printf("enter the age of first person : ");
	scanf("%d",&p1);
	printf("enter the age of second person : ");
	scanf("%d",&p2);
	printf("enter the age of third person : ");
	scanf("%d",&p3);
	if(p1>p2 && p1>p3)
	{
		printf("p1 is big");
	}
	else if(p2>p1 && p2>p3)
	{
		printf("p2 is big ");
	}
	else
	{
		printf("p3 is big");
	}
	getch();
}