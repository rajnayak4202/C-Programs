#include<stdio.h>
#include<conio.h>
void main()
{
  int a;
  int b;
  char oprator;
  float ans;
  clrscr();
  printf("Enter first vaalue:");
  scanf("%d",&a);
  printf("Please enter an oprator:");
  scanf("%c",&oprator);
  printf("Enter second value:");
  scanf("%d",&b);
    if(oprator=='+')
      {
	ans=a+b;
	printf("Addition is:%f",ans);
      }
    else if(oprator=='-')
      {
	ans=a-b;
	printf("Subtraction is:%f",ans);
      }
    else if(oprator=='*')
      {
	ans=a*b;
	printf("Multiplication is:%f",ans);
      }
    else if(oprator=='/')
      {
	ans=a/b;
	printf("Devision is:%f",ans);
      }
    else
      {
	printf("This is not an oprator please enter '+', '-', '*', '/' ");
      }
  getch();
}
