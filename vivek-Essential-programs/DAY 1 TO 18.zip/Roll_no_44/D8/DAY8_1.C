#include<stdio.h>
#include<conio.h>
void main()
{
    printf("number=%3d\n",10);
    printf("number=%2d\n",10);
    printf("number=%1d\n",10);
    printf("number=%7.2f\n",5.4321);
    printf("number=%.2f\n",5.4392);
     printf("number=%.9f\n",5.4321);
    getch();
}

