#include<stdio.h>
#include<conio.h>
void main()
{
   int n1;
   int n2;
   int n3;
   clrscr();
   printf("Enter first no.:");
   scanf("%d",&n1);
   printf("Enter second no.:");
   scanf("%d",&n2);
   printf("Enter third no.:");
   scanf("%d",&n3);
    (n1>n2 & n1>n3) ? printf("- First number is the biggest number -") : printf("");
    (n2>n1 & n2>n3) ? printf("- Second number is the biggest number -") : printf("");
    (n3>n1 & n3>n2) ? printf("- Third number is the biggest number -" ) : printf("");
   getch();
}