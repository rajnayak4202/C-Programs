#include<stdio.h>
#include<conio.h>
void main()
{
   float f=10.25f;
   int i;
   clrscr();
   i=f*100;
   printf("PAISA is:%d",i);
   getch();
}