#include<stdio.h>
#include<conio.h>
void main()
{
  int x,a,b,c;
  a=2;
  b=4;
  c=5;
  clrscr();
  x=a--+b++-++c;
  printf("x:%d",x);
  getch();
}