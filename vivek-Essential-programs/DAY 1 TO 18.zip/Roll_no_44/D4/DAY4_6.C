#include<stdio.h>
#include<conio.h>
void main()
{
   int a=20;
   int b=10;
   float c=0;
   clrscr();
   (float)c=(int)a/(int)b;
   printf("Devision of two number is:%f",&c);
   getch();
}