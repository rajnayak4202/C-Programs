//area of triangle programme
#include <stdio.h>
#include <conio.h>

void main()

{
	clrscr();
	printf("size of int : %d",sizeof(int));
	printf("\nsize of float : %d",sizeof(float));
	printf("\nsize of char : %d",sizeof(char));
	printf("\nsize of long : %d",sizeof(long));
	printf("\nsize of double : %d",sizeof(double));
	getch();
}
