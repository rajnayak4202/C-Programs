#include<stdio.h>
#include<conio.h>
void main()
{
  clrscr();
  printf("value of integer is:%d",sizeof(int));
  printf("\nvalue of character is:%d",sizeof(char));
  printf("\nvalue of float is:%d",sizeof(float));
  printf("\nvalue of double is:%d",sizeof(double));
  getch();
}