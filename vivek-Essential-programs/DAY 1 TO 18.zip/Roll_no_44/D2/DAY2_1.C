//Write a program to print a value into the center using "\t" & "\n".
#include<stdio.h>
#include<conio.h>
void main()
{
 clrscr();
   printf("\t\t\t\t-:Student detail:-");
   printf("\n\n\n\t\t\tName:Ravindra");
   printf("\n\t\t\tAddress:Swaminarayan park-8");
   printf("\n\t\t\tMobile no is:7486823895");
   printf("\n\t\t\tEmail id is:ravindraunuri@gmail.com");
   getch();
}