#include<stdio.h>
#include<conio.h>
void main()
{
   int a;
   int ans;
   clrscr();
   printf("Enter number:");
   scanf("%d",&a);
   ans=a*1;
   printf("%d",ans);
   ans=a*2;
   printf("\n%d",ans);
   ans=a*3;
   printf("\n%d",ans);
   ans=a*4;
   printf("\n%d",ans);
   ans=a*5;
   printf("\n%d",ans);
   ans=a*6;
   printf("\n%d",ans);
   ans=a*7;
   printf("\n%d",ans);
   ans=a*8;
   printf("\n%d",ans);
   ans=a*9;
   printf("\n%d",ans);
   ans=a*10;
   printf("\n%d",ans);
   getch();
}